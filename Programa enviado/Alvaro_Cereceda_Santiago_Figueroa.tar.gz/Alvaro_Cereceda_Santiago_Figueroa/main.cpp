/*
Este main es solo para probar, hay que borrarlo
despues. Se deberia poder usar algo como esto en
python una vez wraped.
*/
#include "grafo.h"
#include <iostream>
using namespace std;

int Node::numero_nodos = 0;
int main(){
    cout << "\nInicio programa." << endl;
    
    cout << "Fin programa.\n\n"<<endl;
}