Integrantes:
    Alvaro Cereceda
    Santiago Figueroa

El archivo GoogleMaps.py es un ejemplo con las cosas que probamos de la tarea.
El archivo test_grafo.py es otro ejemplo con las implementaciones de la tarea.
El pdf tiene una imagen con el grafo creado en google maps.
